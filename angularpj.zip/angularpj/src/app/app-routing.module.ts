import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { ListviewComponent } from './listview/listview.component';
import { OrdersComponent } from './orders/orders.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CardComponent } from './card/card.component';
import { TedComponent } from './ted/ted.component';
import { EditComponent } from './edit/edit.component';
import { AddComponent } from './add/add.component';
import { SerComponent } from './ser/ser.component';
const routes: Routes = [
  {path:'Customer',component:CustomerComponent},
  {path:'listview',component:ListviewComponent},
  {path:'orders',component:OrdersComponent},
  {path:'about',component:AboutComponent},
  {path:'login',component:LoginComponent},
  {path:'card',component:CardComponent},
  {path:'ted',component:TedComponent},
  {path:'edit',component:EditComponent},
  {path:'new',component:AddComponent},
  {path:'ser',component:SerComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
